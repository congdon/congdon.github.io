Edited by CBC, Tue Oct  9 11:25:54 2018
------------------------------------------------------------

In the following the instructions for starting up this example:
* "Desktop/Decentalized_Learning_Optimization/Backend/" represents the path
	to the Backend System (directory containing the config.json file)
* "xGraph/Modules/" represents the path to the modules directory pulled
  down from the release on GitHub 
* "Desktop/Decentalized_Learning_Optimization/Modules/" represents the
  path to the modules directory in the example (sent directly)

CBC: I adapted that notion and instead of trying to run from my home, I
first cd'd into the directory for DLO... so the pathnames are shorter

CBC: Each system is run from a different shell (Terminal for me, whatever
for you). I guess that might be why Trevor started at his home directory,
cause I had to 'cd' to the right place for each new window.


1. Start the backend server first
TREVOR:
xgraph -r --cwd Desktop/Decentalized_Learning_Optimization/Backend/ --xgraph xGraph/Modules/ --local Desktop/Decentalized_Learning_Optimization/Modules/

CBC:
(cd to correct directory, and:)
xgraph -r --cwd Backend --xgraph mb://modulebroker.xgraphdev.com --local Modules

2. Start the environment / display server. 

TREVOR:
xgraph -r --cwd Desktop/Decentalized_Learning_Optimization/Environment/
--xgraph xGraph/Modules/ --local
Desktop/Decentalized_Learning_Optimization/Modules/

CBC:
(cd to correct directory, and:)
xgraph -r --cwd Environment --xgraph mb://modulebroker.xgraphdev.com --local Modules

3. Once this is runnng you can direct your browser to localhost:8080. A
screen should be displayed with the tile Example Chart and a loading icon
"Waiting on Data". 


4a. Start one or both of the optimizers. When finished running they will
display the true environment being sampled.

TREVOR:
xgraph -r --cwd
Desktop/Decentalized_Learning_Optimization/ML-EpsilonGreedy/ --xgraph
xGraph/Modules/ --local
Desktop/Decentalized_Learning_Optimization/Modules/

CBC:
(cd to correct directory, and:)
xgraph -r --cwd ML-EpsilonGreedy --xgraph mb://modulebroker.xgraphdev.com --local Modules

4b. (other optimizer)

TREVOR:
xgraph -r --cwd Desktop/Decentalized_Learning_Optimization/ML-Softmax/ --xgraph xGraph/Modules/ --local Desktop/Decentalized_Learning_Optimization/Modules/

CBC:
xgraph -r --cwd ML-Softmax --xgraph mb://modulebroker.xgraphdev.com --local Modules


